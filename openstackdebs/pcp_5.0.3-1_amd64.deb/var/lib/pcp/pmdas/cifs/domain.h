/*
 * built from ../../pmns/stdpmid
 */
#define CIFS 121
