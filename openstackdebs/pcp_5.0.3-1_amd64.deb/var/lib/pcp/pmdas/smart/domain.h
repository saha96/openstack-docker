/*
 * built from ../../pmns/stdpmid
 */
#define SMART 150
