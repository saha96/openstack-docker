/*
 * built from ../../pmns/stdpmid
 */
#define PIPE 128
