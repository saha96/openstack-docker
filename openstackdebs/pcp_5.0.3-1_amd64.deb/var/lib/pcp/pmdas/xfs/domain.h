/*
 * built from ../../pmns/stdpmid
 */
#define XFS 11
