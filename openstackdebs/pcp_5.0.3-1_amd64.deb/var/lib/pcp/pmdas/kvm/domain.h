/*
 * built from ../../pmns/stdpmid
 */
#define KVM 95
