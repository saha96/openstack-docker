/*
 * built from ../../../pmns/stdpmid
 */
#define MMV 70
#define PMPROXY 4
