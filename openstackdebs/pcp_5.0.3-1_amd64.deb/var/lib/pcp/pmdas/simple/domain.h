/*
 * built from ../../pmns/stdpmid
 */
#define SIMPLE 253
