/*
 * built from ../../pmns/stdpmid
 */
#define TRIVIAL 250
