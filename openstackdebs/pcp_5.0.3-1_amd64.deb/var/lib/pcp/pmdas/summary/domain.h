/*
 * built from ../../pmns/stdpmid
 */
#define SYSSUMMARY 27
