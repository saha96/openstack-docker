/*
 * built from ../../pmns/stdpmid
 */
#define LINUX 60
