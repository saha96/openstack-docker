/*
 * built from ../../pmns/stdpmid
 */
#define ROOMTEMP 69
